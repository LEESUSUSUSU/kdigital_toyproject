package toy.project.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import toy.project.demo.domain.Review;
import toy.project.demo.persistance.ReviewRepository;
import toy.project.demo.persistance.ReviewRepository.InvalidPasswordException;
import toy.project.demo.persistance.ReviewRepository.ReviewNotFoundException;

@Service
@RequiredArgsConstructor
public class ReviewService {

    @Autowired
    ReviewRepository reviewRepository;
    
    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    public Review insertReview(String username, String notename, byte[] image, String notePass, String note,String sw_name) {
        Review review = new Review();
        review.setUsername(username);
        review.setNotename(notename);
        review.setNotePass(notePass);
        review.setNote(note);
        review.setSw_name(sw_name);
       
        // Check if the image data is null or empty before setting it
        if (image != null && image.length > 0) {
            review.setImage(image);
        }
       
     
        return reviewRepository.save(review);
    }

    
   
    public Review updateReview(Integer seq,String notename, byte[] image, String notepass, String note) {
        Review review = reviewRepository.findById(seq).orElse(null);
        if (review != null && review.getNotePass().equals(notepass)) {
            review.setNotename(notename);
            
            // Check if the image data is null or empty before setting it
            if (image != null && image.length > 0) {
                review.setImage(image);
            }
            review.setNotePass(notepass);
            review.setNote(note);
            
            return reviewRepository.save(review);
        }
        return null; // Handle error here if the review is not found or the notepass doesn't match
    }

    public Review deleteReview(Integer seq, String notepass) throws ReviewNotFoundException, InvalidPasswordException {
        Review review = reviewRepository.findById(seq).orElse(null);
        if (review != null) {
            if (notepass.equals(review.getNotePass())) {
                System.out.println("삭제되었습니다");
                reviewRepository.delete(review);
                return review;
            } else {
                throw new InvalidPasswordException("비밀번호가 올바르지 않습니다.");
            }
        } else {
            throw new ReviewNotFoundException("해당하는 리뷰를 찾을 수 없습니다.");
        }
    }

   

	

	

	
	}

