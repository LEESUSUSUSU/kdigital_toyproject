package toy.project.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import toy.project.demo.domain.member1;
import toy.project.demo.domain.member2;
import toy.project.demo.persistance.UserRepository;
import toy.project.demo.persistance.Member2Repository;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class DataController {

	@Autowired
	UserRepository userRepository;
	@Autowired
	Member2Repository member2Repository;

	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/main/members")
	public List<Object[]> getAllMembers() {
		return userRepository.findAllCombinedData();
	}

	@GetMapping("/main/member2")
	public List<member2> getAllMembers2() {
		return member2Repository.findAll(); // Correctly calling member2Repository
	}
}
