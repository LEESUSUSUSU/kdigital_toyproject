package toy.project.demo.persistance;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import toy.project.demo.domain.member2;


public interface Member2Repository extends JpaRepository<member2, String>{

	  List<member2> findAll();
	
}
