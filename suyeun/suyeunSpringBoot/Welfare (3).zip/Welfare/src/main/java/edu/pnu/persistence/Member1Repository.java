package edu.pnu.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.pnu.domain.Member1;

public interface Member1Repository extends JpaRepository<Member1, Integer> {

}
